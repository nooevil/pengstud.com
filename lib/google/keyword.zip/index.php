<?php
namespace Google\AdsApi\Examples\AdWords\v201710\Optimization;

require 'vendor/autoload.php';

use Google\AdsApi\AdWords\AdWordsServices;
use Google\AdsApi\AdWords\AdWordsSession;
use Google\AdsApi\AdWords\AdWordsSessionBuilder;
use Google\AdsApi\AdWords\v201710\cm\Language;
use Google\AdsApi\AdWords\v201710\cm\NetworkSetting;
use Google\AdsApi\AdWords\v201710\cm\Paging;
use Google\AdsApi\AdWords\v201710\o\AttributeType;
use Google\AdsApi\AdWords\v201710\o\IdeaType;
use Google\AdsApi\AdWords\v201710\o\LanguageSearchParameter;
use Google\AdsApi\AdWords\v201710\o\LocationSearchParameter;
use Google\AdsApi\AdWords\v201710\o\NetworkSearchParameter;
use Google\AdsApi\AdWords\v201710\o\RelatedToQuerySearchParameter;
use Google\AdsApi\AdWords\v201710\o\RequestType;
use Google\AdsApi\AdWords\v201710\o\SeedAdGroupIdSearchParameter;
use Google\AdsApi\AdWords\v201710\o\TargetingIdeaSelector;
use Google\AdsApi\AdWords\v201710\o\TargetingIdeaService;
use Google\AdsApi\Common\OAuth2TokenBuilder;
use Google\AdsApi\Common\Util\MapEntries;


class GetKeywordIdeas {

    // If you do not want to use an existing ad group to seed your request, you
    // can set this to null.
    const AD_GROUP_ID = null;
    const PAGE_LIMIT = 100;

    public static function runExample(AdWordsServices $adWordsServices,
                                      AdWordsSession $session, $adGroupId)
    {
        $result_keyword = array();
        $targetingIdeaService =
            $adWordsServices->get($session, TargetingIdeaService::class);

        // Create selector.
        $selector = new TargetingIdeaSelector();
        $selector->setRequestType(RequestType::IDEAS);
        $selector->setIdeaType(IdeaType::KEYWORD);
        $selector->setRequestedAttributeTypes([
            AttributeType::KEYWORD_TEXT,
            AttributeType::SEARCH_VOLUME,
            AttributeType::AVERAGE_CPC,
            AttributeType::COMPETITION,
            AttributeType::CATEGORY_PRODUCTS_AND_SERVICES
        ]);

        $paging = new Paging();
        $paging->setStartIndex(0);
        $paging->setNumberResults(10);
        $selector->setPaging($paging);

        $searchParameters = [];
        // Create related to query search parameter.
        $relatedToQuerySearchParameter = new RelatedToQuerySearchParameter();

        if(isset($_POST['getKeyword'])) {
            $keyword_to_search = explode("\r\n", $_POST['keywords']);
            foreach ($keyword_to_search as $kw_search) {
                if(empty($kw_search)) {
                    unset($kw_search);
                }
            }
        }

        $str = implode(',',$keyword_to_search);
        $relatedToQuerySearchParameter->setQueries([
             $str
        ]);
        $searchParameters[] = $relatedToQuerySearchParameter;

        // Create language search parameter (optional).
        // The ID can be found in the documentation:
        // https://developers.google.com/adwords/api/docs/appendix/languagecodes
        $languageParameter = new LanguageSearchParameter();

        //print_r($languageParameter);
        $english = new Language();
        $english->setId(1031);
        $languageParameter->setLanguages([$english]);
        $searchParameters[] = $languageParameter;

        // Create network search parameter (optional).
        $networkSetting = new NetworkSetting();
        $networkSetting->setTargetGoogleSearch(true);
        $networkSetting->setTargetSearchNetwork(false);
        $networkSetting->setTargetContentNetwork(false);
        $networkSetting->setTargetPartnerSearchNetwork(false);


        $networkSearchParameter = new NetworkSearchParameter();
        $networkSearchParameter->setNetworkSetting($networkSetting);
        $searchParameters[] = $networkSearchParameter;
        //$searchParameters[] = $location;

        // Optional: Use an existing ad group to generate ideas.

        $selector->setSearchParameters($searchParameters);
        $selector->setPaging(new Paging(0, self::PAGE_LIMIT));

        // Get keyword ideas.
        $page = $targetingIdeaService->get($selector);

        // Print out some information for each targeting idea.
        $entries = $page->getEntries();
        if ($entries !== null) {
            foreach ($entries as $targetingIdea) {
                $data = MapEntries::toAssociativeArray($targetingIdea->getData());
                $keyword = $data[AttributeType::KEYWORD_TEXT]->getValue();
                $searchVolume =
                    ($data[AttributeType::SEARCH_VOLUME]->getValue() !== null)
                        ? $data[AttributeType::SEARCH_VOLUME]->getValue() : 0;
                $averageCpc = $data[AttributeType::AVERAGE_CPC]->getValue();
                $competition = $data[AttributeType::COMPETITION]->getValue();
                $categoryIds =
                    ($data[AttributeType::CATEGORY_PRODUCTS_AND_SERVICES]->getValue()
                        === null)
                        ? $categoryIds = '' : implode(
                        ', ',
                        $data[AttributeType::CATEGORY_PRODUCTS_AND_SERVICES]->getValue()
                    );

                $keyword_obj = new  \stdClass();
                $keyword_obj->keyword = $keyword;
                $keyword_obj->search_volume = $searchVolume;
                $keyword_obj->average_CPC =  ($averageCpc === null) ? 0 : $averageCpc->getMicroAmount();
                $keyword_obj->competition =  $competition;
                $keyword_obj->categories =  $categoryIds;

                $result_keyword[] = $keyword_obj;
                unset($keyword_obj);
            }
        }

        if (empty($entries)) {
            return false;
        }
        return $result_keyword;
    }

    public static function main() {
        // Generate a refreshable OAuth2 credential for authentication.
        $oAuth2Credential = (new OAuth2TokenBuilder())
            ->fromFile(__DIR__.'/config/adsapi_php.ini')
            ->build();

        // Construct an API session configured from a properties file and the OAuth2
        // credentials above.
        $session = (new AdWordsSessionBuilder())
            ->fromFile(__DIR__.'/config/adsapi_php.ini')
            ->withOAuth2Credential($oAuth2Credential)
            ->build();
        return self::runExample(new AdWordsServices(), $session, self::AD_GROUP_ID);
    }
}
if(isset($_POST['getKeyword'])) {
    $results = GetKeywordIdeas::main();
}
?>

<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="google-site-verification" content="RHO2-jfezSV3d-1Kq4W49k8az4kBkcIPP87bTVrKJaM" />
<body>

<div>
    <form method="post">
        <div>Введите ключевые слова, каждое сочетание с новой строки</div>
        <textarea name="keywords" rows="10"cols="100"></textarea>
        <input type="submit" name="getKeyword" value="Make magic">
    </form>
</div>
<table style="border: 1px solid;padding: 5px">
        <th>keyword</th>
        <th>search_volume</th>
        <th>average_CPC</th>
        <th>competition</th>
        <th>categories</th>
    <?php foreach ($results as $r) :?>
        <tr>
            <td><?php echo $r->keyword ?></td>
            <td><?php echo $r->search_volume ?></td>
            <td><?php echo $r->average_CPC ?></td>
            <td><?php echo $r->competition ?></td>
            <td><?php echo $r->categories ?></td>
        </tr>
    <?php endforeach; ?>
</table>

</body>

</html>
